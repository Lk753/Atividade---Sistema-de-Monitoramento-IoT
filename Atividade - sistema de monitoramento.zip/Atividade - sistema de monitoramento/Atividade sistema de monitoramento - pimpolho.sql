INSERT INTO locais (nome_local, descricao)
VALUES
('laboratorio', 'sala de testes'),
('escritorio', 'area_administrativa'),
('escritorio', 'area_financeira'),
('sala_reuniao', 'area_comercial')
